# 安装 DSH Bot 原生插件

插件安装在你现有的官方 DSH 内。模型凭据、工作目录、审批和原生会话沿用 DSH 配置。

## 1. 检查宿主和安装依赖

首版兼容基线：Linux／macOS、官方 `@deepseek-ai/dsh@0.2.0-rc.2`、Node `^22.19.0 || >=24`。官方插件管理器通过 `pnpm` 安装依赖；验收固定使用 `pnpm@11.19.0`。

```bash
node --version
dsh --version
pnpm --version
```

尚未安装官方 DSH 时，先按官方说明完成安装和模型配置。npm 安装方式为：

```bash
npm install -g @deepseek-ai/dsh@0.2.0-rc.2 pnpm@11.19.0
dsh web
```

确认普通 DSH 会话可以发送消息并获得模型答复，再安装本插件。已有 DSH 的用户只需补齐缺失的 `pnpm`。

## 2. 获取并验证插件包

在 [GitHub Release](https://github.com/86cloudyun-afk/dsh-bot/releases/tag/v1.0.0) 中打开 [插件包](https://raw.githubusercontent.com/86cloudyun-afk/dsh-bot/v1.0.0/dist/dsh-bot-1.0.0.tgz) 和 [校验文件](https://raw.githubusercontent.com/86cloudyun-afk/dsh-bot/v1.0.0/dist/SHA256SUMS) 链接保存；也可以在下载目录运行：

```bash
curl -fLO https://raw.githubusercontent.com/86cloudyun-afk/dsh-bot/v1.0.0/dist/dsh-bot-1.0.0.tgz
curl -fLO https://raw.githubusercontent.com/86cloudyun-afk/dsh-bot/v1.0.0/dist/SHA256SUMS
```

Linux：

```bash
sha256sum -c SHA256SUMS
```

macOS：

```bash
shasum -a 256 -c SHA256SUMS
```

应显示插件文件校验通过。Release 同时提供兼容版本、源代码身份和验收报告。

## 3. 安装到日常 profile

以下命令使用官方 `web` profile。使用其他现有 Web profile 时，将 `web` 替换为你实际使用的名称。

```bash
dsh plugin --profile web add ./dsh-bot-1.0.0.tgz --ignore-scripts --strict-peer-dependencies
dsh web
```

本插件没有安装脚本。无需替换宿主目录、设置产品专用 `DSH_HOME` 或运行额外的 Bot 服务。

在 DSH 侧栏选择 **插件**，确认已安装的 `dsh-bot` 已启用。然后打开 **Bot 工作台**。首次进入会从 DSH 读取模型目录；模型不存在时，请先在 DSH 中配置模型。

## 4. 创建第一个 Bot

在 **Bots → 创建具名 Bot** 中填写名称即可开始；职责可以选填，模型默认选中 DSH 当前配置的模型，也可以为这个 Bot 另选一个。

创建后，在 Bot 卡片点击 **开始聊天**，直接进入该 Bot 的原生会话。也可以点击 **新建 Bot 会话 → 选择已创建的 Bot → 开始对话**。

原生工作工具默认使用 DSH 当前提供的工具，原生审批沿用 DSH。无需逐个填写工具名；已有 Bot 也不再受旧工具清单限制。

需要定制时展开 **更多设置**：工作目录、执行模型、思考程度、回复长度与原生会话配置都在这里。工作目录默认沿用 DSH。执行模型选择“与聊天模型相同”时自动跟随聊天模型；明确选择某个模型时保持该选择，即使两者暂时相同。新建 Bot 默认沿用当前 DSH 的模型与思考设置；两种会话的回复长度仍可分别设置。远程 DSH 的自定义工作目录应填写远程机器上存在的绝对目录。

工作台常用导航只有 **Bots、任务、记忆、协作、管理**。内部群与会议在“协作”；共享与授权、会话管理、结果与投递在“管理”。

## 5. 验证一次完整使用流程

1. 在 **记忆** 中选中 Bot，保存一句长期事实；为同一 Bot 新建另一个会话，询问它的名称和该事实。
2. 在 **任务** 中选择负责人，填写标题和目标；验收条件及结果接收会话可在“验收与结果接收”中选填，点击 **登记任务 → 开始／接续**。
3. 长任务运行期间继续与该 Bot 聊新话题，再启动一个短任务。短任务可以先返回，长任务保留自己的运行状态。
4. 点击 **查看执行** 打开实际原生执行日志；需要时调整目标、接续或停止本次尝试。结果返回后用 **记录验收** 保存通过、待定或不通过及证据。
5. 归档已结算任务或会话，再从工作台恢复，确认身份和历史保留。

内部群、会议、持续授权和普通会话管理见 [使用手册](guide.zh-CN.md)。

## 6. 升级、禁用与卸载

关闭插件开关会停止插件管理的运行、结算资源并移除工作台入口；原生历史和长期记忆仍保存。重新启用后读取原账本，未明确结算的工作保留未知状态。

官方 rc.2 的插件管理器升级方式是先卸载，再安装新版。先让工作结算或明确停止，并使用 DSH 自己的备份方式保存现有 profile 数据，然后：

```bash
dsh plugin --profile web remove dsh-bot --config.ignore-scripts=true
dsh plugin --profile web add ./dsh-bot-1.0.0.tgz --ignore-scripts --strict-peer-dependencies
```

重新启动或启用插件后，Bot ID、记忆、会话和任务读取原持久数据。卸载只移除插件依赖与入口；手动删除 DSH 存储不属于卸载步骤。

## 7. 故障处理

| 现象 | 处理 |
| --- | --- |
| `pnpm was not found` | 安装 `pnpm@11.19.0`，确认启动 DSH 的环境可以执行 `pnpm --version`。 |
| 工作台没有出现 | 在原有侧栏“插件”中确认 `dsh-bot` 启用；检查官方 DSH 版本和该 profile 的运行诊断。 |
| 模型列表为空／无法回答 | 先确认普通 DSH 对话正常，再检查该 Bot 的模型配置和 DSH 凭据。 |
| `model_drift` | Bot 会话使用 Bot 配置的模型。回工作台调整联络／执行模型，再发起新轮或新尝试。 |
| `revision_conflict` | 另一页面已经修改对象。当前 Bot 配置草稿保留；点击“重新载入最新配置”后按新版本修改。 |
| `access_denied` | 在“共享与授权”核对接收 Bot、共享上限、具体会话／任务范围和有效权限。 |
| 停止已接受，但还未结算 | 等待模型、工具、作业、终端或子工作的真实终止证据；占用会在结算后释放。 |
| 状态为 `UNKNOWN`／“未知” | 使用“结果与投递”及待查回的原始操作查询实际日志。不要重新登记替代任务来掩盖未知状态。 |
| 同一 profile 写入者冲突 | 关闭该 profile 的重复宿主进程，再正常启动；多个浏览器页面可以连接同一个宿主。 |
| 存储损坏／版本不兼容 | 保留原 profile 和日志，读取诊断；插件会拒绝覆盖坏数据。 |

[旧独立软件版及其安装器已作废](history/standalone-void.md)。它们不作为本插件的安装步骤或依赖。
