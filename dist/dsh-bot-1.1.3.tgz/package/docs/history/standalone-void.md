# 已作废：旧独立软件版

2026-10-08，用户明确要求全部改为可直接安装到官方原版 DSH 的插件。旧独立应用、Host 装配、SDK 覆盖、owner 启动器、专用 Home/profile、独立网页和相应安装器全部作废，不再支持安装、启动或交付。

这些运行入口已从当前源码、包导出和打包范围移除。原始记录、旧分支和归档资产在仓库历史中保留，以供追溯；部分历史分支的原始文件链接仍可读取。它们不受支持、不属于当前交付，也不参与原生插件安装。当前源码与插件安装包只包含原生插件，不携带旧 Host。

历史 Release `v0.1.0-private.1` 及附件属于作废的软件版；旧测试、私有 Host/GUI 证据不计入原生插件验收。不要下载旧安装包作为插件使用。作废是当前支持与交付状态，不代表所有历史字节已删除或不可访问；本轮原生插件审计也不认定历史修改 Host 的许可已重新核清。PR #1 保持未合并。

原生插件的正式交付以 [已批准规格](https://github.com/86cloudyun-afk/dsh-bot/blob/v1.1.0/docs/superpowers/specs/2026-10-08-native-dsh-plugin-v1-design.md) 的 P01–P21 为验收条件，包括多 Bot、记忆、群、真实会议、并发联络、双平台完整安装和最终分发审计。具体版本与证据见原生插件 Release。

当前版本为 **v1.1.3**，使用官方未修改的 DSH 0.2.0-rc.2，保持 schema 2 与协议 2。安装与升级以 [当前说明](../install.zh-CN.md) 和 [本版验收记录](https://github.com/86cloudyun-afk/dsh-bot/blob/v1.1.3/docs/releases/v1.1.3-qualification.zh-CN.md) 为准。
