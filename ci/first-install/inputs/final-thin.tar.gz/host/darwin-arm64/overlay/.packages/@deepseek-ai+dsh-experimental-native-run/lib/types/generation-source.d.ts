import { Context } from '@deepseek-ai/cordis';
import type { Agent, AgentHandle } from '@deepseek-ai/dsh-agent';
import type { LlmCallConfig, ProtectedModelCalls, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { DeepSeekProviderFactory } from '@deepseek-ai/dsh-llm-deepseek';
import { type UserMessage } from '@deepseek-ai/dsh-session';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { OwnedGenerationJournal, OwnedGenerationHistorySelector } from './generation-journal.ts';
declare const generationBrand: unique symbol;
declare const receiptBrand: unique symbol;
/** Exact product identifiers retained by the source; these fields grant no authority. */
export interface NativeGenerationBinding {
    readonly botId: string;
    readonly taskId: string;
    readonly sessionId: string;
    readonly generation: number;
    readonly botEpoch: number;
    readonly taskEpoch: number;
    readonly taskRevision: number;
    readonly authorityEpoch: number;
    readonly configVersion: string;
}
/** Complete pre-reserved original parent-work execution, including the actual held slot lease. */
export interface OwnedWorkGenerationBinding extends NativeGenerationBinding {
    readonly operationId: string;
    readonly nonce: string;
    readonly inputMessageId: string;
    readonly messageIdentity: string;
    readonly slotLease: Readonly<Record<string, JsonValue>>;
}
/** Source-minted process-local identity of one original input and native driver. */
export interface OwnedNativeGeneration {
    readonly [generationBrand]: true;
}
/** Durable settlement identity recognized only by its exact producing source. */
export interface OwnedNativeGenerationReceipt {
    readonly [receiptBrand]: true;
    readonly sessionId: string;
}
/** Exact native-attested original input window; serialized source labels never qualify extra inputs. */
export interface NativeGenerationInputWindow {
    readonly sessionId: string;
    readonly inputMessageId: string;
    readonly startSeq: number;
    readonly endSeq: number;
    readonly runtimeContexts: readonly {
        readonly seq: number;
        readonly messageId: string;
        readonly messageDigest: string;
    }[];
    readonly runtimeContextMessageIds: readonly string[];
}
/** Independent local and remote outcomes; only a branded receipt grants terminal evidence. */
export interface NativeGenerationView {
    readonly binding: NativeGenerationBinding;
    readonly inputMessageId: string;
    readonly activityCounter: number;
    readonly requestCount: number;
    readonly local: 'pending' | 'returned';
    readonly remote: 'UNKNOWN' | 'settled';
    readonly usageKnown: boolean;
    readonly usage: TokenUsage | null;
    readonly receipt: OwnedNativeGenerationReceipt | null;
    readonly reason: string | null;
}
/** Owner-only source retaining native identities rather than serializable task proofs. */
export interface OwnedGenerationSource {
    start(binding: NativeGenerationBinding, input: UserMessage): OwnedNativeGeneration;
    restore(binding: NativeGenerationBinding): Promise<OwnedNativeGeneration>;
    restoreKnown(selector: OwnedGenerationHistorySelector): Promise<OwnedNativeGeneration>;
    inspect(generation: OwnedNativeGeneration): Promise<NativeGenerationView>;
    cancel(generation: OwnedNativeGeneration, timeoutMs?: number): Promise<NativeGenerationView>;
}
/** Private source preparation before native mounting or any waking input. */
export interface PrepareOwnedGenerationOptions {
    readonly ownerCtx: Context;
    readonly providerFactory: DeepSeekProviderFactory;
    readonly sessionId: string;
    readonly role: 'main' | 'work';
    readonly route: LlmCallConfig;
    readonly delegateTool?: ToolDefinition;
    readonly initialization?: {
        readonly permissionPreset: string;
        readonly sandboxMode: string;
        readonly approvalPolicy: string;
    };
    readonly isCurrent: (binding: NativeGenerationBinding) => boolean;
    /** Request fence, independent of authority to verify the exact original receipt. */
    readonly canDispatch?: (binding: NativeGenerationBinding) => boolean;
    readonly journal?: OwnedGenerationJournal;
    /** Complete pre-reserved original input for zero-tool work or a privately derived child. */
    readonly plannedBinding?: OwnedWorkGenerationBinding;
    /** Exact genuine sealed historical plan for resume; it grants no new start or replay. */
    readonly historicalPlan?: OwnedGenerationHistorySelector;
    readonly workDelegate?: {
        readonly plannedBinding: OwnedWorkGenerationBinding;
        readonly delegateTool: ToolDefinition;
    };
}
/** Factory call capability and one-shot attachment to the actual created handle. */
export interface PreparedOwnedGenerationSource {
    readonly mode: 'create' | 'resume';
    /** Actual parent Agent only for a source-derived child; pass it unchanged to the native factory. */
    readonly parentAgent?: Agent;
    readonly protectedModelCalls: ProtectedModelCalls;
    attach(handle: AgentHandle, options?: {
        readonly delegateTool?: ToolDefinition;
    }): OwnedGenerationSource;
}
/** Private child preparation; role and recursion policy are derived from the original parent. */
export type OwnedChildGenerationOptions = Omit<PrepareOwnedGenerationOptions, 'role' | 'delegateTool' | 'workDelegate'>;
/** Recognize actual strict provider preparation before any native creation effects.
 * @param value Candidate producer preparation, never a structural route label.
 * @param ownerCtx Exact source owner Context.
 * @param sessionId Exact Session to create.
 * @param role Exact main or work tool policy.
 * @returns Whether the provider minted this preparation for these identities.
 */
export declare function isPreparedOwnedGenerationSource(value: unknown, ownerCtx: Context, sessionId: string, role: 'main' | 'work'): value is PreparedOwnedGenerationSource;
/** Recognize an unchanged source belonging to the exact owner Context.
 * @param value Candidate live process-local source.
 * @param ownerCtx Exact lifecycle creator Context.
 * @returns Whether the native producer minted this source for that owner.
 */
export declare function isOwnedGenerationSource(value: unknown, ownerCtx: Context): value is OwnedGenerationSource;
/** Verify terminal evidence from the source and product binding that produced it.
 * @param value Candidate receipt; copied JSON never qualifies.
 * @param source Exact retained native source.
 * @param binding Exact generation and epochs to consume.
 * @returns Whether this source durably settled that binding and original activity.
 */
export declare function isOwnedGenerationReceipt(value: unknown, source: OwnedGenerationSource, binding: NativeGenerationBinding): value is OwnedNativeGenerationReceipt;
/** Read original input/context facts only from the exact source-branded settled receipt.
 * @param value Exact producing receipt; copied fields have no authority.
 * @param source Actual source that settled the original generation.
 * @param binding Full original product binding, including operation, nonce and lease.
 * @returns Frozen native input-window facts, or null when the receipt is not genuine.
 */
export declare function getOwnedGenerationReceiptInputWindow(value: unknown, source: OwnedGenerationSource, binding: NativeGenerationBinding): NativeGenerationInputWindow | null;
/** Mint strict calls before creation, then attach only the real same-owner native handle.
 * @param options Provider, lifecycle owner, exact route and tool policy.
 * @returns Opaque preparation with a one-shot actual-handle attachment.
 */
export declare function prepareOwnedGenerationSource(options: PrepareOwnedGenerationOptions): PreparedOwnedGenerationSource;
/** Derive one zero-tool child only from an actual original parent delegate activity.
 * @param parentSource Exact retained parent-work source.
 * @param parentGeneration Its original native generation capability.
 * @param options Same owner, provider and private child policy.
 * @returns A factory-branded depth-one preparation; JSON lineage grants no authority.
 */
export declare function prepareOwnedChildGenerationSource(parentSource: OwnedGenerationSource, parentGeneration: OwnedNativeGeneration, options: OwnedChildGenerationOptions): PreparedOwnedGenerationSource;
/** Restore only the exact sealed original child through its genuine historical parent source and capability.
 * A newer parent activity must belong to this source and have complete durable settlement.
 * @param parentSource Actual resumed parent source with its immutable delegate policy.
 * @param parentGeneration Genuine restored original parent generation, never a serialized lineage.
 * @param options Exact child journal and owner policy; no future input needs to be invented.
 * @returns Protected same-id child preparation retaining the actual native parent Agent.
 */
export declare function prepareOwnedKnownChildGenerationSource(parentSource: OwnedGenerationSource, parentGeneration: OwnedNativeGeneration, options: OwnedChildGenerationOptions): Promise<PreparedOwnedGenerationSource>;
/** Plan the next parent-work input through its actual owner after the preceding run settled.
 * @param source Exact retained parent-work source.
 * @param ownerCtx Exact source lifecycle owner, never a JSON identity.
 * @param binding Complete next pre-reserved original input, operation, nonce and held slot lease.
 */
export declare function planOwnedWorkGenerationSource(source: OwnedGenerationSource, ownerCtx: Context, binding: OwnedWorkGenerationBinding): void;
/** Bind a retained blank actual native handle before its first input.
 * @param options Same-owner native handle and strict source policy.
 * @returns Private source; GUI creation uses prepareOwnedGenerationSource before mounting.
 */
export declare function createOwnedGenerationSource(options: Omit<PrepareOwnedGenerationOptions, 'sessionId'> & {
    readonly handle: AgentHandle;
}): OwnedGenerationSource;
export {};
//# sourceMappingURL=generation-source.d.ts.map