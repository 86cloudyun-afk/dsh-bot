/** Native Session consumer: real inbox/loop/receipts with provider-owned guarded calls. */
import type { Context } from '@deepseek-ai/cordis';
import type { GenerateOptions, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { DeepSeekProviderFactory } from '@deepseek-ai/dsh-llm-deepseek';
import type { NativeRunHost } from './journal.ts';
import type { NativeControlId, NativeOperation, NativeOperationId, NativeSessionReceipt, NativeTarget, NativeTargetId } from './types.ts';
/** Private runtime-owner consumer; it does not establish public human authorization. */
export declare class NativeSessionDriver {
    #private;
    private readonly ctx;
    private readonly host;
    private readonly binding;
    private constructor();
    /** Create a native owned Session with its exact preset and protection before publication.
     * @param ctx Actual trusted runtime owner context, not a JSON principal.
     * @param host Open exclusive native journal owner.
     * @param targetId Current Session-bound target.
     * @param provider Actual provider-owned opaque factory.
     * @returns Registered native consumer owning its lifecycle handle.
     */
    static createOwned(ctx: Context, host: NativeRunHost, targetId: NativeTargetId, provider: DeepSeekProviderFactory): Promise<NativeSessionDriver>;
    /** Resume with protection already attached before any reconstructed inbox wake.
     * Unknown journal work remains unexecutable; this method never drives it.
     * @param ctx Actual trusted runtime owner context.
     * @param host Already reopened authoritative journal; missing state cannot be synthesized.
     * @param targetId Exact current Session-bound target.
     * @param provider Actual provider-owned opaque factory.
     * @returns Registered consumer after native persistence reconstruction.
     */
    static resumeOwned(ctx: Context, host: NativeRunHost, targetId: NativeTargetId, provider: DeepSeekProviderFactory): Promise<NativeSessionDriver>;
    /** Prove concrete owned native handle identity, never structural JSON.
     * @returns Whether the exact native factory-returned handle is retained.
     */
    hasNativeOwner(): boolean;
    /** Revalidate the actual Session/preset/tool relationship at each host-owned boundary.
     * @param current Complete operation binding, including native/control versions.
     */
    validateSessionBinding(current: NativeTarget): void;
    /** Claim journal input, then drive actual native turns; unknown state never wakes the Agent.
     * @param caller Exact trusted owner fiber capability accepted by the journal policy.
     * @param operationId Admitted journal-local identity.
     * @returns Durable native journal outcome after owned local activity returns.
     */
    drive(caller: object, operationId: NativeOperationId): Promise<NativeOperation>;
    /** Host-only final native request ownership check; no caller-supplied authorization callback.
     * @param options Actual request instance.
     * @param op Exact journal operation.
     * @param step Pending journal step.
     */
    validateIntent(options: GenerateOptions, op: NativeOperation, step: number): void;
    /** Host verifies an exact private attestation created only after native durable readback.
     * @param receipt Candidate Session receipt identity.
     * @param op Exact journal operation.
     * @param step Consumed journal step.
     * @param answer Actual native terminal text.
     * @param observed Actual native terminal usage.
     */
    validateReceipt(receipt: NativeSessionReceipt | undefined, op: NativeOperation, step: number, answer: string, observed: TokenUsage): void;
    /** Fence the exact generation before native cancellation and bounded local drain.
     * @param caller Exact owner fiber capability.
     * @param controlId Idempotent stop receipt.
     * @param operationId Operation specifying the generation.
     * @returns Durable outcome retaining remote uncertainty.
     */
    stop(caller: object, controlId: NativeControlId, operationId: NativeOperationId): Promise<NativeOperation>;
    /** Abort/drain only locally active work with the exact fenced generation.
     * @param targetId Target to stop.
     * @param generation Exact generation, excluding restarted work.
     * @returns Whether owned activity returned within the settlement bound.
     */
    drainGeneration(targetId: NativeTargetId, generation: number): Promise<boolean>;
    /** Cancel active work only after its target mutation has committed.
     * @param targetId Revoked/changed target.
     */
    abortTarget(targetId: NativeTargetId): void;
    /** Fence owned work and release the actual native handle only after bounded quiescence. */
    close(): Promise<void>;
}
//# sourceMappingURL=session-driver.d.ts.map