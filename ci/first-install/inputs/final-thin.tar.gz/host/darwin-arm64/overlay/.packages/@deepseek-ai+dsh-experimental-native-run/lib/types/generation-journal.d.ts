import { Context } from '@deepseek-ai/cordis';
import type { NativeActivityIntegrity } from '@deepseek-ai/dsh-agent-loop';
import type { GenerateOptions, LlmCallConfig, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { DeepSeekDispatchInput } from '@deepseek-ai/dsh-llm-deepseek';
import type { SessionHeader, UserMessage } from '@deepseek-ai/dsh-session';
import type { NativeGenerationBinding, PrepareOwnedGenerationOptions } from './generation-source.ts';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { OwnedGenerationControlAuthority } from './generation-authority.ts';
declare const journalBrand: unique symbol;
/** Process-local journal identity; serialized fields never mint source authority. */
export interface OwnedGenerationJournal {
    readonly [journalBrand]: true;
    close(): Promise<void>;
}
/** Complete original creation data; a main creation does not invent model/task coordinates. */
export interface OwnedGenerationCreationIntent {
    readonly binding: Readonly<Record<string, JsonValue>>;
    readonly operationId: string;
    readonly nonce: string;
}
/** Stable native policy expected before any protected creation or resume. */
export interface OpenOwnedGenerationJournalOptions {
    readonly ownerCtx: Context;
    readonly directory: string;
    readonly create: boolean;
    readonly sessionId: string;
    readonly role: 'main' | 'work';
    /** Explicit owner opt-in for parent work; ordinary work and derived children stay zero-tool. */
    readonly toolPolicy?: 'zero' | 'delegate';
    readonly route: LlmCallConfig;
    readonly initialization?: PrepareOwnedGenerationOptions['initialization'];
    readonly session: {
        readonly cwd: string;
        readonly agentPreset: string;
    };
    readonly creationIntent?: OwnedGenerationCreationIntent;
}
interface Dispatch {
    requestDigest: string;
    wireDigest: string;
    endpoint: string;
}
interface Response {
    assistantSeq: number;
    turn: number;
    step: number;
    streamDigest: string;
    usage: TokenUsage;
}
interface Settlement {
    activityCounter: number;
    endSeq: number;
    endChain: string;
    windowDigest: string;
    originalReturned: true;
    responses: Response[];
    usage: TokenUsage;
    runtimeContexts: Array<{
        seq: number;
        messageId: string;
        messageDigest: string;
    }>;
}
interface Generation {
    key: string;
    binding: NativeGenerationBinding;
    input: UserMessage;
    startSeq: number;
    startChain: string;
    dispatches: Dispatch[];
    settlement: Settlement | null;
}
/** Producer-only original parent binding; callers cannot mint it from serialized lineage. */
export interface NativeOwnedParentLineage {
    readonly parentSourceId: string;
    readonly parentBinding: NativeGenerationBinding;
    readonly parentInput: UserMessage;
    readonly toolCallId: string;
    readonly toolCallSeq: number;
    readonly childSessionId: string;
    readonly nativeDepth: number;
}
/** Internal native producer operations; only the exact journal capability opens this port. */
export interface NativeGenerationJournalPort {
    readonly mode: 'create' | 'resume';
    readonly sourceId: string;
    assertActive(): void;
    assertParentCapability(derived: boolean): void;
    bindOriginalParent(lineage: NativeOwnedParentLineage): void;
    readOriginalParent(): Promise<NativeOwnedParentLineage>;
    proveOriginalDelegate(lineage: NativeOwnedParentLineage): Promise<void>;
    assertUnfenced(): void;
    assertLatest(key: string): void;
    assertBlank(intent: OwnedGenerationCreationIntent, integrity: NativeActivityIntegrity): void;
    fence(subject: string): void;
    clearFence(): void;
    proveFullKnown(): Promise<void>;
    assertKnownPlan(binding: NativeGenerationBinding, expectedDigest: string): void;
    readHistory(binding: NativeGenerationBinding): Promise<Generation & {
        settlement: Settlement;
    }>;
    assertToolPolicy(toolDigest: string): void;
    assertCanStart(binding: NativeGenerationBinding, integrity: NativeActivityIntegrity): void;
    readKnown(binding: NativeGenerationBinding): Promise<Generation & {
        settlement: Settlement;
    }>;
    attach(header: SessionHeader, integrity: NativeActivityIntegrity, toolDigest: string): void;
    begin(binding: NativeGenerationBinding, input: UserMessage, integrity: NativeActivityIntegrity): string;
    dispatch(key: string, options: GenerateOptions, wire: DeepSeekDispatchInput): void;
    settle(key: string, settlement: Settlement): void;
}
declare const historySelectorBrand: unique symbol;
/** Read-only selector minted from complete sealed native history under the exclusive journal writer. */
export interface OwnedGenerationHistorySelector {
    readonly [historySelectorBrand]: true;
}
/** Select exact complete known history under its genuine exclusive journal and current owner grant.
 * @param journal Actual reopened exclusive journal.
 * @param ownerCtx Exact lifecycle owner Context.
 * @param input Full original immutable execution binding.
 * @param authority Pinned live read grant; it does not authorize new dispatch.
 * @returns Opaque historical selector after full durable native history readback.
 */
export declare function selectOwnedGenerationHistory(journal: OwnedGenerationJournal, ownerCtx: Context, input: NativeGenerationBinding, authority: OwnedGenerationControlAuthority): Promise<OwnedGenerationHistorySelector>;
/** Recognize the genuine live selector for the complete original binding.
 * @param value Candidate opaque selector.
 * @param journal Exact exclusive producing journal.
 * @param ownerCtx Exact current lifecycle owner.
 * @param binding Complete original operation, nonce, lease and product coordinates.
 * @returns Whether the original producer retains this exact live selector.
 */
export declare function isOwnedGenerationHistorySelector(value: unknown, journal: OwnedGenerationJournal, ownerCtx: Context, binding: NativeGenerationBinding): value is OwnedGenerationHistorySelector;
/** Internal consumer; only a native source attached to this same journal may retain a historical selector. */
export declare function openNativeGenerationHistorySelector(selector: OwnedGenerationHistorySelector, journal: OwnedGenerationJournal, ownerCtx: Context): {
    journal: OwnedGenerationJournal;
    ownerCtx: Context;
    binding: NativeGenerationBinding;
    authorize(): void;
    assertOriginalPlan(): void;
    read(): Promise<Generation & {
        settlement: Settlement;
    }>;
};
/** Recognize the actual exclusive journal for the exact lifecycle owner and native Session.
 * @param value Candidate journal, never parsed metadata.
 * @param ownerCtx Exact runtime owner Context.
 * @param sessionId Original Session identity.
 * @param role Exact main or work role.
 * @returns Whether the native journal minted this capability for those identities.
 */
export declare function isOwnedGenerationJournal(value: unknown, ownerCtx: Context, sessionId: string, role: 'main' | 'work'): value is OwnedGenerationJournal;
/** Open the producer port after exact capability and policy verification.
 * @param value Actual journal capability retained by its owner.
 * @param options Preparation policy for this original native Session.
 * @returns Native-only durable intent and settlement operations.
 */
export declare function openNativeGenerationJournalPort(value: OwnedGenerationJournal, options: PrepareOwnedGenerationOptions): NativeGenerationJournalPort;
/** Acquire a private native writer and verify known history before any resume can wake.
 * @param options Exact owner, original Session, private directory and immutable policy.
 * @returns Exclusive process-local journal capability; UNKNOWN histories reject reopening.
 */
export declare function openOwnedGenerationJournal(input: OpenOwnedGenerationJournalOptions): Promise<OwnedGenerationJournal>;
export {};
//# sourceMappingURL=generation-journal.d.ts.map