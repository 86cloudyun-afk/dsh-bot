export interface OwnedGenerationControlAuthority {
    readonly isAuthorized: () => boolean;
    readonly isDispatchFenced: () => boolean;
}
export interface PinnedGenerationControlAuthority {
    authorize(): void;
    assertFenced(): void;
}
export declare function pinGenerationControlAuthority(input: OwnedGenerationControlAuthority): PinnedGenerationControlAuthority;
/** Original operation and nonce are mandatory for historical control, never invented from coordinates. */
export declare function assertOwnedControlBinding(binding: object): void;
//# sourceMappingURL=generation-authority.d.ts.map