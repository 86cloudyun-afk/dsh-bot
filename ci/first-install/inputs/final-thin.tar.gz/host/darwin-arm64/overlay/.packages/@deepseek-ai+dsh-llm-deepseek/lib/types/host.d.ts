/** Shared Host wiring for the DeepSeek protocol adapter. */
import type { Context } from '@deepseek-ai/cordis';
import type { GenerateOptions, ProtectedModelCalls } from '@deepseek-ai/dsh-llm';
import type { DeepSeekAdapterOptions, DeepSeekConnectionOptions, DeepSeekDispatchControl } from './types.ts';
/** Recognize a provider-created capability owned by this actual LLM runtime.
 * @param value Candidate factory identity, never serialized data.
 * @param runtime Exact owner runtime where the native Session will run.
 * @returns Whether the provider privately created this factory in that runtime.
 */
export declare function isDeepSeekProviderFactory(value: unknown, runtime: Context['llm'] | undefined): value is DeepSeekProviderFactory;
/** Owned control and persistence checkpoint; credentials never cross this interface. */
export interface DeepSeekSessionControl extends DeepSeekDispatchControl {
    /** Flush the exact owned native Session before entering guarded transport.
     * @param options Actual native request to checkpoint and revalidate.
     */
    beforeStream(options: GenerateOptions): Promise<void>;
}
/** Provider-owned opaque factory available only to trusted same-process consumers. */
export interface DeepSeekProviderFactory {
    /** Permanently seal ordinary calls and mint a private guarded adapter factory.
     * @param sessionId Exact native Session identity.
     * @param control Mandatory admission, final dispatch and checkpoint controls.
     * @returns An opaque native call capability without credential callbacks.
     */
    protectSession(sessionId: NonNullable<GenerateOptions['sessionId']>, control: DeepSeekSessionControl): ProtectedModelCalls;
}
/**
 * Register one provider with request-local transport services and live retry policy.
 * @param ctx - provider plugin lifetime with the LLM registry injected.
 * @param provider - exact route owned by this plugin.
 * @param dependencies - provider-owned discovery, credential, and configuration callbacks.
 * @returns Provider-owned protected Session call factory.
 */
export declare function registerDeepSeekProvider<C extends DeepSeekConnectionOptions>(ctx: Context, provider: string, dependencies: Pick<DeepSeekAdapterOptions<C>, 'options' | 'resolveAuth' | 'providerName' | 'discoverModels'>): DeepSeekProviderFactory;
//# sourceMappingURL=host.d.ts.map