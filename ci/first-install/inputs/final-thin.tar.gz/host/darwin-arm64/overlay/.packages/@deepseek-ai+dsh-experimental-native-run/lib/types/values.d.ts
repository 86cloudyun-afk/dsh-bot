import type { RequestMessage, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { NativeAdmission, NativeOperation, NativeTarget, NativeSessionBinding, NativeSessionReceipt } from './types.ts';
/** Reject a controlled operation with its exact machine-readable reason. */
export declare function reject(code: string): never;
/** Encode JSON with sorted object keys; unsupported values reject. */
export declare function canonical(value: unknown): string;
/** Hash only the supplied non-secret input; authentication is never passed here. */
export declare function digest(value: unknown): string;
/** Reproduce only the accepted zero-tool text Messages projection at final wire validation.
 * Empty native system anchors carry no prompt and are omitted by the provider.
 * @param input Frozen native or direct text history.
 * @returns Canonical user/assistant wire turns, merging adjacent equal roles.
 */
export declare function textWire(input: readonly RequestMessage[]): Array<{
    role: 'user' | 'assistant';
    content: Array<{
        type: 'text';
        text: string;
    }>;
}>;
/** Narrow a parsed JSON object. */
export declare function record(value: unknown): value is Record<string, unknown>;
/** Recognize a nonnegative exact integer. */
export declare function integer(value: unknown): value is number;
/** Validate a journal-local identifier. */
export declare function id(value: unknown): value is string;
/** Parse the complete persisted native Session relationship.
 * @param value Parsed candidate binding.
 * @returns Validated detached binding.
 */
export declare function sessionBinding(value: unknown): NativeSessionBinding;
/** Parse exact flushed native settlement coordinates and integrity digests.
 * @param value Candidate receipt.
 * @returns Validated detached receipt.
 */
export declare function sessionReceipt(value: unknown): NativeSessionReceipt;
/** Validate every required authority field read from disk or admission JSON. */
export declare function target(value: unknown): NativeTarget;
/** Validate one complete immutable queued input. */
export declare function admission(value: unknown, maxSteps: number): NativeAdmission;
/** Hash the admitted text and generation together. */
export declare function admissionDigest(value: NativeAdmission): string;
/** Accept usage only from an observed terminal response with exact counts. */
export declare function usage(value: unknown): value is TokenUsage;
/** Sum independently observed step usage; unknown attempts are never counted as zero. */
export declare function knownUsage(op: NativeOperation): TokenUsage;
/** Validate complete durable operation rows before any driver or inspection reads them. */
export declare function operation(value: unknown, maxSteps: number): NativeOperation;
//# sourceMappingURL=values.d.ts.map