/** Private controls retain exact original native identities without authorizing a new input. */
import { Context } from '@deepseek-ai/cordis';
import type { OwnedGenerationSource, OwnedNativeGeneration, NativeGenerationBinding, NativeGenerationView } from './generation-source.ts';
import type { OwnedGenerationCreationIntent } from './generation-journal.ts';
import type { OwnedGenerationControlAuthority } from './generation-authority.ts';
/** Durable archive result; local return and remote accounting remain separate. */
export interface OwnedSessionArchiveResult {
    readonly sessionId: string;
    readonly archived: true;
    readonly original: NativeGenerationView | null;
}
/** Exact-original read, cancellation and archive; this capability has no start or factory method. */
export interface OwnedGenerationControl {
    inspect(): Promise<NativeGenerationView>;
    cancel(timeoutMs?: number): Promise<NativeGenerationView>;
    archive(): Promise<OwnedSessionArchiveResult>;
}
/** A complete original empty creation has no fabricated generation or cancel capability. */
export interface OwnedBlankSessionControl {
    archive(): Promise<OwnedSessionArchiveResult>;
}
export interface NativeOriginalControlPort {
    assertOriginal(): void;
    fence(): void;
    inspect(authorize: () => void): Promise<NativeGenerationView>;
    cancel(timeoutMs: number | undefined, authorize: () => void): Promise<NativeGenerationView>;
}
/** Internal native closures, opened only by the actual attached source. */
export interface NativeSourceControlPort {
    readonly ownerCtx: Context;
    readonly sessionId: string;
    assertActive(): void;
    original(generation: OwnedNativeGeneration, binding: NativeGenerationBinding): NativeOriginalControlPort;
    assertBlank(intent: OwnedGenerationCreationIntent): void;
    fenceBlank(intent: OwnedGenerationCreationIntent): void;
    proveDurable(authorize: () => void): Promise<void>;
    assertResumable(): void;
    proveKnown(authorize: () => void): Promise<void>;
    clearFence(): void;
}
export declare function bindNativeSourceControlPort(source: OwnedGenerationSource, port: NativeSourceControlPort): void;
/** Mount the actual stock lineage gate privately without any controller or RPC plugin.
 * @param ownerCtx Exact native source owner with the actual Workspace registry.
 */
export declare function mountOwnedGenerationArchiveGate(ownerCtx: Context): Promise<void>;
/** Admit the actual original before product epoch changes; future authority never permits dispatch.
 * @param source Actual retained native source with an exclusive journal.
 * @param generation Original opaque native generation.
 * @param ownerCtx Exact source lifecycle owner.
 * @param input Complete original binding including operation, nonce and lease.
 * @param authority Pinned actual owner grant and durable product fence callbacks.
 * @returns Exact-original control without start or factory authority.
 */
export declare function admitOwnedGenerationControl(source: OwnedGenerationSource, generation: OwnedNativeGeneration, ownerCtx: Context, input: NativeGenerationBinding, authority: OwnedGenerationControlAuthority): OwnedGenerationControl;
/** Verify the exact original control and its current actual owner grant.
 * @param value Candidate opaque control.
 * @param source Original producing source.
 * @param generation Original producing generation.
 * @param ownerCtx Exact current lifecycle owner.
 * @param binding Complete original immutable binding.
 * @returns Whether this is the original live producer control.
 */
export declare function isOwnedGenerationControl(value: unknown, source: OwnedGenerationSource, generation: OwnedNativeGeneration, ownerCtx: Context, binding: NativeGenerationBinding): value is OwnedGenerationControl;
/** Admit only the complete, sealed original empty creation, with no synthetic generation coordinates.
 * @param source Actual protected source with the original empty journal and native initialization.
 * @param ownerCtx Exact lifecycle owner.
 * @param input Immutable actual pre-native creation intent with original operation and nonce.
 * @param authority Pinned actual owner grant and durable product fence callbacks.
 * @returns Archive-only empty-source control; a racing input invalidates it.
 */
export declare function admitOwnedBlankSessionControl(source: OwnedGenerationSource, ownerCtx: Context, input: OwnedGenerationCreationIntent, authority: OwnedGenerationControlAuthority): OwnedBlankSessionControl;
/** Recognize an unchanged genuine blank control under its actual live owner grant.
 * @param value Candidate archive-only control.
 * @param source Actual original blank source.
 * @param ownerCtx Exact lifecycle owner.
 * @param intent Complete original immutable creation intent.
 * @returns Whether the native producer still retains this exact blank control.
 */
export declare function isOwnedBlankSessionControl(value: unknown, source: OwnedGenerationSource, ownerCtx: Context, intent: OwnedGenerationCreationIntent): value is OwnedBlankSessionControl;
/** Unarchive only an attached genuine same-id resume after complete sealed history verification.
 * @param source Actual same-id protected resumed source, before any new native activity.
 * @param ownerCtx Exact current lifecycle owner.
 * @param authority Pinned current actual owner grant; no historical JSON admits dispatch.
 */
export declare function unarchiveOwnedGenerationSource(source: OwnedGenerationSource, ownerCtx: Context, authority: OwnedGenerationControlAuthority): Promise<void>;
//# sourceMappingURL=generation-control.d.ts.map