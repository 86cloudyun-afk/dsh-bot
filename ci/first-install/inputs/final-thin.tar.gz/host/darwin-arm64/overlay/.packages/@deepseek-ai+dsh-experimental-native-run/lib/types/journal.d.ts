import type { DeepSeekAdapterOptions, DeepSeekDispatchInput } from '@deepseek-ai/dsh-llm-deepseek';
import type { GenerateOptions, TokenUsage } from '@deepseek-ai/dsh-llm';
import { NativeRunDriver } from './driver.ts';
import type { NativeAdmission, NativeControlId as ControlId, NativeOperation, NativeOperationId, NativeRunConfig, NativeTarget, NativeTargetChange, NativeTargetId, NativeRunConsumer, NativeSessionReceipt } from './types.ts';
interface CapacityView {
    executionSlotsAvailable: number;
    contactSlotsAvailable: number;
    executionTokensAvailable: number;
    contactTokensAvailable: number;
}
/** Native journal owner for one host; its launcher caller policy is process-local and test-only. */
export declare class NativeRunHost {
    #private;
    private constructor();
    /** Acquire the native lock and open a fresh or strictly validated existing journal.
     * @param config Explicit test launcher, target and capacity configuration.
     * @returns The exclusive native journal owner.
     */
    static open(config: NativeRunConfig): Promise<NativeRunHost>;
    /** Check current calling scope, including same-ID inspection.
     * @param caller Actual calling scope object.
     * @param action Requested invocation, inspection or control.
     * @param targetId Target-specific scope when the operation identifies a target.
     */
    authorize(caller: object, action: 'invoke' | 'inspect' | 'control', targetId?: NativeTargetId): void;
    /** Read a detached current target without waking a driver.
     * @param caller Actual calling scope with inspection authority.
     * @param targetId Journal-local target identity.
     * @returns The frozen current target binding.
     */
    target(caller: object, targetId: NativeTargetId): NativeTarget;
    /** Read a detached durable operation without a model request.
     * @param caller Actual calling scope with current inspection authority.
     * @param operationId Journal-local operation identity.
     * @returns The frozen durable operation.
     */
    inspect(caller: object, operationId: NativeOperationId): NativeOperation;
    /** Read journal authority for one Session without deriving operations from JSONL.
     * @param caller Actual owner with inspection authority for every matching target.
     * @param sessionId Exact persisted Session identity.
     * @returns Detached operations belonging to that Session across generations.
     */
    sessionOperations(caller: object, sessionId: string): readonly NativeOperation[];
    /** Commit input, complete binding, deduplication receipt and reservation atomically.
     * @param caller Actual calling scope with invocation authority.
     * @param requested Complete target binding and bounded pending text steps.
     * @returns The committed operation or identical existing receipt.
     */
    admit(caller: object, requested: NativeAdmission): Promise<NativeOperation>;
    /** Commit an authority change before cancellation or success receipt.
     * @param caller Actual calling scope with current control authority.
     * @param targetId Target whose authority changes.
     * @param change Explicit revoke, archive, restart or model mutation.
     * @returns The committed current target binding.
     */
    changeTarget(caller: object, targetId: NativeTargetId, change: NativeTargetChange): NativeTarget;
    /** Construct a controlled consumer; arbitrary adapters cannot be substituted.
     * @param dependencies Existing provider dependencies without a dispatch guard override.
     * @returns A consumer registered with this native owner.
     */
    driver(dependencies: Omit<DeepSeekAdapterOptions, 'dispatchControl'>): NativeRunDriver;
    /** Track consumers so direct construction cannot evade host disposal.
     * @param driver Concrete consumer registered by its constructor.
     */
    registerDriver(driver: NativeRunConsumer): void;
    /** Claim one consumer before asynchronous preparation begins.
     * @param caller Actual calling scope with invocation authority.
     * @param operationId Admitted operation to consume.
     * @param driver Registered concrete consumer claiming local ownership.
     */
    claimDriver(caller: object, operationId: NativeOperationId, driver: NativeRunConsumer): void;
    /** Release only the consumer whose complete local lifecycle returned.
     * @param operationId Operation whose local lifecycle returned.
     * @param driver Exact current consumer owner.
     */
    releaseDriver(operationId: NativeOperationId, driver: NativeRunConsumer): void;
    /** Abort and drain every consumer after the generation fence is durable.
     * @param caller Actual calling scope with current control authority.
     * @param operationId Operation identifying the already-fenced generation.
     */
    drainStoppedGeneration(caller: object, operationId: NativeOperationId): Promise<void>;
    /** Deployment bound for local drain; expiry never claims remote settlement. */
    get settlementDeadlineMs(): number;
    /** Read remaining local allocations while unknown work retains its reserves.
     * @param caller Actual calling scope with inspection authority.
     * @returns Remaining host-local slots and token allocations.
     */
    capacity(caller: object): CapacityView;
    /** Verify a bound request against the authoritative pending step.
     * @param caller Actual calling scope with current invocation authority.
     * @param operationId Admitted operation identity.
     * @param step Exact pending step index.
     * @returns The frozen journaled operation for this step.
     */
    checkRequest(caller: object, operationId: NativeOperationId, step: number): NativeOperation;
    /** Persist an attempt after final synchronous validation; no await is allowed here.
     * @param caller Actual calling scope checked at final dispatch.
     * @param driver Exact consumer owning the operation.
     * @param operationId Journal-local operation identity.
     * @param step Exact pending step index.
     * @param options Frozen request input bound by the controlled consumer.
     * @param wire Frozen endpoint and serialized payload immediately preceding fetch.
     */
    beginAttempt(caller: object, driver: NativeRunConsumer, operationId: NativeOperationId, step: number, options: GenerateOptions, wire: DeepSeekDispatchInput): void;
    /** Record a terminal response; release complete-operation capacity only with known usage.
     * @param driver Exact consumer owning the operation.
     * @param operationId Journal-local operation identity.
     * @param step Exact consumed step index.
     * @param answer Observed terminal text answer.
     * @param observed Independently observed provider token counts.
     * @param receipt Required private native persistence attestation for Session consumers.
     */
    completeStep(driver: NativeRunConsumer, operationId: NativeOperationId, step: number, answer: string, observed: TokenUsage, receipt?: NativeSessionReceipt): void;
    /** Preserve unknown allocations; retain a late local failure alongside known settlement.
     * @param driver Exact consumer whose local lifecycle returned.
     * @param operationId Journal-local operation identity.
     * @param failureCode Non-secret machine-readable failure category.
     */
    failStep(driver: NativeRunConsumer, operationId: NativeOperationId, failureCode: string): void;
    /** Persist an exact-generation no-dispatch fence before local abort.
     * @param caller Actual calling scope with current control authority.
     * @param controlId Idempotent journal-local control receipt identity.
     * @param operationId Operation identifying the generation to stop.
     * @returns The durable operation after the stop fence commits.
     */
    stop(caller: object, controlId: ControlId, operationId: NativeOperationId): NativeOperation;
    /** Fence only an exact native-owned operation, independently of caller revocation.
     * @param driver Exact consumer owning this operation.
     * @param operationId Owned operation to fence before disposal abort.
     */
    stopOwned(driver: NativeRunConsumer, operationId: NativeOperationId): void;
    /** Retain uncertainty when local transport misses its drain deadline.
     * @param driver Exact consumer still owning the operation.
     * @param operationId Owned operation whose closure is unproven.
     */
    noteUnsettled(driver: NativeRunConsumer, operationId: NativeOperationId): void;
    /** Drain local consumers before releasing the kernel-owned writer descriptor. */
    close(): Promise<void>;
}
export {};
//# sourceMappingURL=journal.d.ts.map