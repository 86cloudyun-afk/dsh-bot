/** Freeze the exact complete delegate object graph; copied metadata never supplies tool authority. */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
export declare function freezeOwnedDelegateDefinition(tool: ToolDefinition): void;
//# sourceMappingURL=generation-tool-policy.d.ts.map