import { z } from 'zod';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** Maintained event chain and input/turn counts; this state grants no ownership. */
export interface NativeActivityIntegrity {
    readonly seq: number;
    readonly chain: string;
    readonly previousChain: string;
    readonly users: number;
    readonly turnStarts: number;
    readonly lastUserDigest: string | null;
    readonly lastTurn: number;
    readonly toolNames: readonly string[];
    readonly initial: readonly {
        readonly type: string;
        readonly data: unknown;
    }[];
    readonly lastEvent: {
        readonly seq: number;
        readonly type: string;
        readonly data: unknown;
    } | null;
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        nativeActivityIntegrity: NativeActivityIntegrity;
    }
}
/** Encode the accepted immutable JSON value with stable object-key order.
 * @param value Accepted Session event data.
 * @returns Deterministic JSON for hashing, never an authentication value.
 */
export declare function nativeEventCanonical(value: unknown): string;
/** Hash one accepted non-secret JSON value.
 * @param value Original event or durable product identity.
 * @returns SHA-256 of canonical JSON.
 */
export declare const nativeEventDigest: (value: unknown) => string;
/** Extend the event chain without retaining historical events.
 * @param previous Chain of the complete preceding prefix.
 * @param event Next accepted event in exact sequence order.
 * @returns Chain hash including that event.
 */
export declare const extendNativeEventChain: (previous: string, event: SessionEvent) => string;
/** Host-only event-order fold used with real native handles and durable readback. */
export declare const nativeActivityIntegrityDefinition: {
    key: "nativeActivityIntegrity";
    stateVersion: number;
    stateSchema: z.ZodType<NativeActivityIntegrity, unknown, z.core.$ZodTypeInternals<NativeActivityIntegrity, unknown>>;
    init: () => {
        seq: number;
        chain: string;
        previousChain: string;
        users: number;
        turnStarts: number;
        lastUserDigest: null;
        lastTurn: number;
        toolNames: never[];
        initial: never[];
        lastEvent: null;
    };
    apply: (state: NoInfer<NativeActivityIntegrity>, event: SessionEvent) => {
        seq: number;
        previousChain: string;
        chain: string;
        users: number;
        turnStarts: number;
        lastUserDigest: string | null;
        lastTurn: number;
        toolNames: readonly string[];
        initial: readonly {
            readonly type: string;
            readonly data: unknown;
        }[];
        lastEvent: {
            seq: import("@deepseek-ai/dsh-session").SessionSeq;
            type: "turn/start" | "turn/end" | "step/start" | "step/end" | "user/message" | "developer/message" | "system/message" | "assistant/message" | "assistant/attempt" | "tool/call" | "tool/result" | "request/header" | "request/context" | "session/end-seed" | "agent/inbox/spliced" | "tool/ptc-dispatch-start" | "tool/ptc-dispatch" | "approval/asked" | "approval/decided" | "approval/policy";
            data: import("@deepseek-ai/dsh-llm").UserMessage | {
                target: import("@deepseek-ai/dsh-agent").InboxTarget;
                start: number;
                removedCount?: number;
                inserted: import("@deepseek-ai/dsh-llm").UserMessage[];
                outcome?: "canceled";
            } | {
                turn: number;
            } | {
                turn: number;
                reason: import("@deepseek-ai/dsh-session").TurnEndReason;
            } | {
                turn: number;
                step: number;
            } | {
                turn: number;
                step: number;
            } | {
                turn: number;
                step: number;
                message: import("@deepseek-ai/dsh-llm").DeveloperMessage;
                headerSeq?: import("@deepseek-ai/dsh-session").SessionSeq;
            } | {
                turn: number;
                step: number;
                message: import("@deepseek-ai/dsh-llm").SystemMessage;
            } | {
                turn: number;
                step: number;
                message: import("@deepseek-ai/dsh-llm").AssistantMessage;
                stream: import("@deepseek-ai/dsh-llm").AssistantStreamRecord[];
                usage?: import("@deepseek-ai/dsh-llm").TokenUsage;
                interrupted?: true;
            } | {
                turn: number;
                step: number;
                stream: import("@deepseek-ai/dsh-llm").AssistantStreamRecord[];
            } | {
                turn: number;
                step: number;
                callId: import("@deepseek-ai/dsh-llm").ToolCallId;
                name: string;
                arguments: string;
            } | {
                turn: number;
                step: number;
                message: import("@deepseek-ai/dsh-llm").ToolResultMessage;
                error?: {
                    name: string;
                    code: string;
                    reason?: string;
                };
                meta?: import("@deepseek-ai/dsh-util-values").JsonValue;
            } | {
                header: import("@deepseek-ai/dsh-session").EpochHeader;
                reason: import("@deepseek-ai/dsh-session").RequestHeaderReason;
                startsSeries?: true;
            } | import("@deepseek-ai/dsh-session").RequestContext | {
                inherited?: true;
            } | import("@deepseek-ai/dsh-tools").PtcDispatchStartEventData | import("@deepseek-ai/dsh-tools").PtcDispatchEventData | {
                id: import("@deepseek-ai/dsh-user-approval").ApprovalRequestId;
                toolName: string;
                callId?: import("@deepseek-ai/dsh-llm").ToolCallId;
                reason?: string;
            } | {
                id: import("@deepseek-ai/dsh-user-approval").ApprovalRequestId;
                outcome: import("@deepseek-ai/dsh-user-approval").ApprovalOutcome;
            } | {
                policy: import("@deepseek-ai/dsh-user-approval").ApprovalPolicy;
                source?: "delegation";
            };
        };
    };
};
//# sourceMappingURL=native-integrity.d.ts.map