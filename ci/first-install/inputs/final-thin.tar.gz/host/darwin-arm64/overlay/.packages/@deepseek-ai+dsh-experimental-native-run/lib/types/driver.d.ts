import type { DeepSeekAdapterOptions } from '@deepseek-ai/dsh-llm-deepseek';
import type { NativeRunHost } from './journal.ts';
import type { NativeControlId as ControlId, NativeOperation, NativeOperationId, NativeTargetId } from './types.ts';
/** Owns a controlled adapter instance; no foreign adapter, JSON actor or message queue can bypass it. */
export declare class NativeRunDriver {
    #private;
    private readonly host;
    constructor(host: NativeRunHost, dependencies: Omit<DeepSeekAdapterOptions, 'dispatchControl'>);
    /** Consume journaled pending steps; unknown outcomes never redispatch.
     * @param caller Actual calling scope checked by the test launcher policy.
     * @param operationId Admitted journal-local identity.
     * @returns The durable outcome after this local consumer returns.
     */
    drive(caller: object, operationId: NativeOperationId): Promise<NativeOperation>;
    /** Commit an exact-generation fence before aborting and draining all matching owners.
     * @param caller Actual calling scope with current control authority.
     * @param controlId Idempotent journal-local control receipt identity.
     * @param operationId Operation identifying the generation to stop.
     * @returns The durable outcome, retaining unknown remote effects.
     */
    stop(caller: object, controlId: ControlId, operationId: NativeOperationId): Promise<NativeOperation>;
    /** Drain only the exact generation after the host has committed its fence.
     * @param targetId Journal-local target identity.
     * @param generation Exact generation to abort.
     * @returns Whether every matching local lifecycle returned before the deadline.
     */
    drainGeneration(targetId: NativeTargetId, generation: number): Promise<boolean>;
    /** Abort requests after the native writer commits an authority change.
     * @param targetId Target whose current authority was changed.
     */
    abortTarget(targetId: NativeTargetId): void;
    /** Persist fences and drain owned local requests before disposal. */
    close(): Promise<void>;
}
//# sourceMappingURL=driver.d.ts.map